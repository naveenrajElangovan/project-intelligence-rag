"""Project Intelligence RAG service."""
